package com.dilaxyx6881.gaminghud

import android.content.Context
import android.hardware.display.DisplayManager
import android.view.Display
import java.io.BufferedReader
import java.io.InputStreamReader
import java.io.RandomAccessFile

/**
 * Kelas untuk membaca data sistem: pemakaian CPU, suhu, dan refresh rate layar.
 * Untuk CPU & suhu, kita coba baca langsung dulu (tanpa root). Kalau gagal
 * (banyak device modern membatasi akses /proc & /sys), kita fallback pakai
 * shell "su" supaya tetap jalan di device root.
 */
object SystemMonitor {

    private var lastIdle = 0L
    private var lastTotal = 0L

    /** Jalankan perintah shell, opsional pakai root ("su -c ..."). */
    private fun runShell(cmd: String, useRoot: Boolean): String {
        return try {
            val process = if (useRoot) {
                ProcessBuilder("su", "-c", cmd).redirectErrorStream(true).start()
            } else {
                ProcessBuilder("sh", "-c", cmd).redirectErrorStream(true).start()
            }
            val reader = BufferedReader(InputStreamReader(process.inputStream))
            val output = reader.readText()
            process.waitFor()
            output
        } catch (e: Exception) {
            ""
        }
    }

    /** Persentase pemakaian CPU (0-100). Dihitung dari delta /proc/stat. */
    fun getCpuUsagePercent(): Int {
        val stat = runShell("cat /proc/stat", useRoot = true).ifBlank {
            runShell("cat /proc/stat", useRoot = false)
        }
        val firstLine = stat.lineSequence().firstOrNull { it.startsWith("cpu ") } ?: return -1
        val parts = firstLine.trim().split(Regex("\\s+")).drop(1).mapNotNull { it.toLongOrNull() }
        if (parts.size < 4) return -1

        val idle = parts[3]
        val total = parts.sum()

        val diffIdle = idle - lastIdle
        val diffTotal = total - lastTotal
        lastIdle = idle
        lastTotal = total

        if (diffTotal <= 0) return 0
        val usage = ((diffTotal - diffIdle) * 100 / diffTotal).toInt()
        return usage.coerceIn(0, 100)
    }

    /** Suhu CPU dalam Celsius. Coba beberapa thermal zone umum. */
    fun getTemperatureCelsius(): Int {
        val zones = listOf(
            "/sys/class/thermal/thermal_zone0/temp",
            "/sys/class/thermal/thermal_zone1/temp",
            "/sys/class/thermal/thermal_zone2/temp"
        )
        for (zone in zones) {
            val raw = runShell("cat $zone", useRoot = true).trim().ifBlank {
                runShell("cat $zone", useRoot = false).trim()
            }
            val value = raw.toLongOrNull() ?: continue
            // Beberapa device melaporkan dalam milli-celsius (misal 38000),
            // sebagian lain sudah dalam celsius langsung (misal 38).
            return if (value > 1000) (value / 1000).toInt() else value.toInt()
        }
        return -1
    }

    /** Refresh rate layar aktif, misal 60/90/120 Hz. Tidak butuh root. */
    fun getRefreshRate(context: Context): Float {
        val dm = context.getSystemService(Context.DISPLAY_SERVICE) as DisplayManager
        val display: Display? = dm.getDisplay(Display.DEFAULT_DISPLAY)
        return display?.refreshRate ?: 60f
    }
}
