package com.dilaxyx6881.gaminghud

import android.app.*
import android.content.Intent
import android.graphics.PixelFormat
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.view.LayoutInflater
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.TextView

class OverlayService : Service() {

    private lateinit var windowManager: WindowManager
    private var overlayView: View? = null
    private val handler = Handler(Looper.getMainLooper())

    private var currentMode = "BALANCE"

    private val updateRunnable = object : Runnable {
        override fun run() {
            updateStats()
            handler.postDelayed(this, 1000)
        }
    }

    override fun onCreate() {
        super.onCreate()
        try {
            startForegroundNotif()
            showOverlay()
            handler.post(updateRunnable)
        } catch (e: Exception) {
            android.widget.Toast.makeText(
                this, "HUD gagal jalan: ${e.message}", android.widget.Toast.LENGTH_LONG
            ).show()
            stopSelf()
        }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        return START_STICKY
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onDestroy() {
        super.onDestroy()
        handler.removeCallbacks(updateRunnable)
        overlayView?.let {
            try { windowManager.removeView(it) } catch (_: Exception) {}
        }
    }

    private fun startForegroundNotif() {
        val channelId = "gaming_hud_channel"
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                channelId, "Gaming HUD", NotificationManager.IMPORTANCE_LOW
            )
            val nm = getSystemService(NotificationManager::class.java)
            nm.createNotificationChannel(channel)
        }
        val notif = NotificationCompatBuilder(this, channelId)
        startForeground(1, notif)
    }

    // Wrapper kecil biar tidak perlu androidx.core notification builder tambahan
    private fun NotificationCompatBuilder(context: Service, channelId: String): Notification {
        val builder = Notification.Builder(context, channelId)
            .setContentTitle("Gaming HUD aktif")
            .setContentText("Memantau performa di latar depan")
            .setSmallIcon(android.R.drawable.ic_menu_compass)
            .setOngoing(true)
        return builder.build()
    }

    private fun showOverlay() {
        windowManager = getSystemService(WINDOW_SERVICE) as WindowManager
        val inflater = LayoutInflater.from(this)
        overlayView = inflater.inflate(R.layout.overlay_widget, null)

        val layoutType = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        } else {
            @Suppress("DEPRECATION")
            WindowManager.LayoutParams.TYPE_PHONE
        }

        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            layoutType,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        )
        params.gravity = android.view.Gravity.TOP or android.view.Gravity.START
        params.x = 40
        params.y = 100

        windowManager.addView(overlayView, params)
        setupDrag(overlayView!!, params)
        setupButtons(overlayView!!)
    }

    /** Supaya HUD bisa digeser-geser posisinya di layar. */
    private fun setupDrag(view: View, params: WindowManager.LayoutParams) {
        var initialX = 0
        var initialY = 0
        var touchX = 0f
        var touchY = 0f

        view.setOnTouchListener { v, event ->
            when (event.action) {
                MotionEvent.ACTION_DOWN -> {
                    initialX = params.x
                    initialY = params.y
                    touchX = event.rawX
                    touchY = event.rawY
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    params.x = initialX + (event.rawX - touchX).toInt()
                    params.y = initialY + (event.rawY - touchY).toInt()
                    windowManager.updateViewLayout(view, params)
                    true
                }
                else -> false
            }
        }
    }

    private fun setupButtons(view: View) {
        view.findViewById<View>(R.id.btnClose).setOnClickListener {
            stopSelf()
        }

        val modeButtons = mapOf(
            "ECO" to view.findViewById<TextView>(R.id.btnEco),
            "DEFAULT" to view.findViewById<TextView>(R.id.btnDefault),
            "BALANCE" to view.findViewById<TextView>(R.id.btnBalance),
            "R-BOOST" to view.findViewById<TextView>(R.id.btnBoost)
        )
        modeButtons.forEach { (mode, btn) ->
            btn.isSelected = (mode == currentMode)
            btn.setOnClickListener {
                currentMode = mode
                modeButtons.values.forEach { it.isSelected = false }
                btn.isSelected = true
                applyPerformanceMode(mode)
            }
        }

        view.findViewById<View>(R.id.btnCleanRam).setOnClickListener {
            runRoot("sync && echo 3 > /proc/sys/vm/drop_caches")
        }
        view.findViewById<View>(R.id.btnDnd).setOnClickListener {
            runRoot("settings put global zen_mode 1")
        }
        view.findViewById<View>(R.id.btnHz).setOnClickListener {
            // Placeholder: ganti refresh rate lewat root butuh perintah spesifik per-device
        }
    }

    /** Terapkan governor CPU sesuai mode yang dipilih (butuh root). */
    private fun applyPerformanceMode(mode: String) {
        val governor = when (mode) {
            "ECO" -> "powersave"
            "DEFAULT" -> "schedutil"
            "BALANCE" -> "schedutil"
            "R-BOOST" -> "performance"
            else -> "schedutil"
        }
        runRoot(
            "for cpu in /sys/devices/system/cpu/cpu*/cpufreq/scaling_governor; do echo $governor > \$cpu; done"
        )
    }

    private fun runRoot(cmd: String) {
        try {
            val process = ProcessBuilder("su", "-c", cmd).start()
            process.waitFor()
        } catch (_: Exception) {
            // Device tidak root / user menolak akses su — abaikan supaya HUD tetap jalan
        }
    }

    private fun updateStats() {
        val view = overlayView ?: return
        val cpu = SystemMonitor.getCpuUsagePercent().coerceAtLeast(0)
        val temp = SystemMonitor.getTemperatureCelsius().coerceAtLeast(0)
        val hz = SystemMonitor.getRefreshRate(this)

        view.findViewById<GaugeView>(R.id.gaugeCpu).apply {
            label = "CPU"
            setValue(cpu, 100, "%")
        }
        view.findViewById<GaugeView>(R.id.gaugeTemp).apply {
            label = "TEMP"
            setValue(temp, 100, "°C")
        }
        view.findViewById<TextView>(R.id.tvFpsHz).text =
            "${hz.toInt()} FPS  •  ${hz.toInt()} Hz"
    }
}
