package com.dilaxyx6881.gaminghud

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.provider.Settings

/**
 * Menyalakan ulang service HUD otomatis setelah perangkat reboot,
 * hanya jika izin overlay sudah pernah diberikan sebelumnya.
 */
class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent?) {
        if (intent?.action == Intent.ACTION_BOOT_COMPLETED) {
            val overlayGranted = Settings.canDrawOverlays(context)
            if (overlayGranted) {
                context.startService(Intent(context, OverlayService::class.java))
            }
        }
    }
}
