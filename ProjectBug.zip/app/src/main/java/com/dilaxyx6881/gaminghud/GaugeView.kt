package com.dilaxyx6881.gaminghud

import android.animation.ValueAnimator
import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.util.AttributeSet
import android.view.View

/**
 * Gauge lingkaran mirip tampilan "R-Boost AI" di referensi: arc oranye
 * dengan angka besar di tengah + label kecil di bawahnya.
 */
class GaugeView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null
) : View(context, attrs) {

    private var progress = 0f          // 0f..1f
    private var animatedProgress = 0f
    var label: String = ""
    var unit: String = "%"
    private var value = 0

    private val bgPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeWidth = 18f
        color = Color.parseColor("#2A2A2A")
        strokeCap = Paint.Cap.ROUND
    }

    private val progressPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeWidth = 18f
        strokeCap = Paint.Cap.ROUND
        shader = null
        color = Color.parseColor("#FF7A18")
    }

    private val valuePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.WHITE
        textSize = 56f
        textAlign = Paint.Align.CENTER
        isFakeBoldText = true
    }

    private val labelPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.parseColor("#AAAAAA")
        textSize = 26f
        textAlign = Paint.Align.CENTER
    }

    private val arcRect = RectF()

    fun setValue(newValue: Int, max: Int = 100, unitLabel: String = "%") {
        value = newValue
        unit = unitLabel
        val target = (newValue.toFloat() / max.toFloat()).coerceIn(0f, 1f)
        ValueAnimator.ofFloat(animatedProgress, target).apply {
            duration = 300
            addUpdateListener {
                animatedProgress = it.animatedValue as Float
                invalidate()
            }
            start()
        }
        progress = target
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val stroke = bgPaint.strokeWidth
        arcRect.set(stroke, stroke, width - stroke, height - stroke)

        val startAngle = 135f
        val sweepFull = 270f

        canvas.drawArc(arcRect, startAngle, sweepFull, false, bgPaint)
        canvas.drawArc(arcRect, startAngle, sweepFull * animatedProgress, false, progressPaint)

        val cx = width / 2f
        val cy = height / 2f
        canvas.drawText("$value$unit", cx, cy + 18f, valuePaint)
        canvas.drawText(label, cx, cy + 60f, labelPaint)
    }
}
