package com.dilaxyx6881.gaminghud

import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.widget.Button
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {

    private lateinit var tvPermStatus: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        tvPermStatus = findViewById(R.id.tvPermStatus)

        findViewById<Button>(R.id.btnGrantPermission).setOnClickListener {
            requestOverlayPermission()
        }
        findViewById<Button>(R.id.btnStartHud).setOnClickListener {
            if (hasOverlayPermission()) {
                startService(Intent(this, OverlayService::class.java))
                Toast.makeText(this, "HUD gaming dimulai", Toast.LENGTH_SHORT).show()
            } else {
                Toast.makeText(this, "Aktifkan izin overlay dulu", Toast.LENGTH_SHORT).show()
                requestOverlayPermission()
            }
        }
        findViewById<Button>(R.id.btnStopHud).setOnClickListener {
            stopService(Intent(this, OverlayService::class.java))
        }
    }

    override fun onResume() {
        super.onResume()
        updatePermissionStatus()
    }

    private fun hasOverlayPermission(): Boolean {
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            Settings.canDrawOverlays(this)
        } else true
    }

    private fun updatePermissionStatus() {
        tvPermStatus.text = if (hasOverlayPermission()) {
            "Izin overlay: sudah aktif ✅"
        } else {
            "Izin overlay: belum diberikan"
        }
    }

    private fun requestOverlayPermission() {
        if (!hasOverlayPermission()) {
            val intent = Intent(
                Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                Uri.parse("package:$packageName")
            )
            startActivity(intent)
        }
    }
}
